/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class ColaProCorrimiento extends TDAPrioridad {
    protected int ini;
    protected int fin;
    protected TDAPrioridad vector[];
    
    public ColaProCorrimiento(int tamano){
        vector = new TDAPrioridad[tamano];
        ini = -1; 
        fin= -1;
    }
////////////////////////////////////////////////////////////////////////////    

    public boolean insertar (TDAPrioridad dato){
        if(estaColaLlena()){
            return false;
        }
        fin++;
        vector[fin]=dato;
        if (ini==-1) {
            ini++;
        }
        if (fin>=1) {
            acomodo(dato);
        }
        return true;
    }
    
    
///////////////////////////////////////////////////////////////////////////    
    public boolean eliminar(){
        if(estaColaVacia())return false;
        
        if(hayUnSoloDato()){
            ini =-1;
            fin =-1;
            return true;
        }
        ini++;
        return true;
    }
    
    
    
    public void acomodo(TDAPrioridad dato) {
        TDAPrioridad re;
        for(int i=fin-1;i>=0;i--) {
            if(dato.getPrioridad()>vector[i].getPrioridad()) {
                re=vector[i];
                vector[i]=dato;
                vector[i+1]=re;
            }
        }
    }
    
    public boolean estaColaLlena(){
        return fin == vector.length-1;
    }
    
    public boolean estaColaVacia(){
        return ini == -1 && fin == -1;
    }
    
    public boolean hayUnSoloDato(){
        return ini == fin;
    }
    
     public int getINI() {
        return ini;
    }

    public int getFIN() {
        return fin;
    }

    public TDAPrioridad getValor(int pos) {
        return vector[pos];
    }
}
