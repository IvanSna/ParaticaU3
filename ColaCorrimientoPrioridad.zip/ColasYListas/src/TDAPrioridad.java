/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class TDAPrioridad {
    private char valor;
    private int prioridad;
    
    public TDAPrioridad(){
        
    }
    
    public TDAPrioridad(char valor,int prioridad){
        this.prioridad= prioridad;
        this.valor=valor;
        
    }

    public void setValor(char valor) {
        this.valor = valor;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getValor() {
        return valor;
    }

    public int getPrioridad() {
        return prioridad;
    }
    
    @Override
    public String toString() {
        return valor + "," + prioridad;
    }
    
}
